<?php
include_once COCCO_CORE_SHORTCODES_PATH . '/blockquote/functions.php';
include_once COCCO_CORE_SHORTCODES_PATH . '/blockquote/blockquote.php';