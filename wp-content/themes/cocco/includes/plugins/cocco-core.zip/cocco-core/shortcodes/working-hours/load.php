<?php

include_once COCCO_CORE_SHORTCODES_PATH . '/working-hours/functions.php';
include_once COCCO_CORE_SHORTCODES_PATH . '/working-hours/working-hours.php';