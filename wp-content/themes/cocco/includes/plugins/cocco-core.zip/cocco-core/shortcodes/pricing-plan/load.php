<?php

include_once COCCO_CORE_SHORTCODES_PATH . '/pricing-plan/functions.php';
include_once COCCO_CORE_SHORTCODES_PATH . '/pricing-plan/pricing-plan.php';
include_once COCCO_CORE_SHORTCODES_PATH . '/pricing-plan/pricing-plan-item.php';