<?php

include_once COCCO_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once COCCO_CORE_CPT_PATH . '/testimonials/helper-functions.php';