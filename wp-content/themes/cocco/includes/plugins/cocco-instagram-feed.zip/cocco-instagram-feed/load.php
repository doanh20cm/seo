<?php

if ( cocco_instagram_feed_is_core_installed() ) {
	include_once 'lib/cocco-instagram-api.php';
	include_once 'widgets/load.php';
}